using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraManager : MonoBehaviour
{
    [Header("Object References")]
    public Camera GameCamera;

    [Header("Camera Settings")]
    public float Mouse = 5;
    public float Roll = .5f;

    [Header("Camera Logic")]
    public CameraLock CurrentLock;

    public bool bIsCamLerping = false;
    public float Zoom;
    public float LerpTimer = 0;
    public float LerpScale = 0.01f;
    public Quaternion oldRotation;
    public Vector3 oldPosition;

    /*
    public void SetOld(Transform oldTrans)
    {
        oldRotation = oldTrans.rotation;
        oldPosition = oldTrans.position;
    }
    */

    public void QuickSnap(Transform target)
    {
        GameCamera.transform.parent = target;
        GameCamera.transform.localPosition = new Vector3(0, 0, 0);
        GameCamera.transform.localEulerAngles = new Vector3(0, 0, 0);
    }
    public void ReParent(CameraLock parent)
    {
        oldRotation = GameCamera.transform.parent.rotation;
        oldPosition = GameCamera.transform.parent.position;
        CurrentLock = parent;
        GameCamera.transform.parent = parent.Socket;
        LerpTimer = 0;
        bIsCamLerping = true;
    }
    public bool ReturnCameraRay(out Ray ray)
    {
        ray = new Ray();
        if (GameCamera == null)
            return false;

        ray = GameCamera.ScreenPointToRay(Input.mousePosition);
        return true;
    }
    void LerpCam()
    {
        if (!bIsCamLerping )
            return;
        if (GameCamera.transform.parent == null)
        { bIsCamLerping = false; return; }

        GameCamera.transform.rotation = Quaternion.Lerp(oldRotation, GameCamera.transform.parent.rotation, LerpTimer);
        GameCamera.transform.position = Vector3.Lerp(oldPosition, GameCamera.transform.parent.position, LerpTimer);
        LerpTimer += LerpScale;

        if (LerpTimer >= 1)
            bIsCamLerping = false;
    }
    void UpdateZoom()
    {
        Zoom += CurrentLock.ZoomScale * -Input.mouseScrollDelta.y;
        Zoom = (Zoom < CurrentLock.ZoomMin) ? CurrentLock.ZoomMin : Zoom;
        Zoom = (Zoom > CurrentLock.ZoomMax) ? CurrentLock.ZoomMax : Zoom;

        Vector3 newPos = CurrentLock.Socket.localPosition;
        newPos.z = -Zoom;
        CurrentLock.Socket.localPosition = newPos;
    }
    void UpdateInput()
    {
        if (Input.GetButtonDown("CamReset"))
        {
            CurrentLock.Boom.localPosition = CurrentLock.DefPos;
            CurrentLock.Boom.localRotation = Quaternion.Euler(CurrentLock.DefRot);
        }

        // Camera Rotate
        if (!Input.GetMouseButton(1))
            return;

        float x = Mouse * Input.GetAxisRaw("Mouse X");
        float y = Mouse * Input.GetAxisRaw("Mouse Y");
        float z = 0;
        if (Input.GetButton("RollLeft"))
            z += 1;
        if (Input.GetButton("RollRight"))
            z -= 1;
        z *= Roll;

        CurrentLock.Boom.Rotate(-y, x, z);
        //CurrentLock.Boom.Rotate(-y, 0, 0, Space.Self);
        //CurrentLock.Boom.Rotate(0, x, 0, Space.Self);

        //CurrentLock.Boom.RotateAround(CurrentLock.Pod.position, CurrentLock.Boom.up, x);
        //CurrentLock.Boom.RotateAround(CurrentLock.Pod.position, CurrentLock.Boom.right, y);
        //CurrentLock.Boom.RotateAround(CurrentLock.Pod.position, CurrentLock.Boom.forward, z);
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        UpdateZoom();
        UpdateInput();
        LerpCam();
    }
}
