using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum ControlMode
{
    FLIGHT,
    TACTICAL
}

public class playerController : MonoBehaviour
{


    [Header("Object References")]
    public Gravity Gravity;

    public CameraManager CameraMan;
    public Rigidbody PhysicsObject;

    //public Transform Flight;
    //public Transform Tactical;
    public Transform Focus;

    public List<CameraLock> CameraLockPoints = new List<CameraLock>();
    public CameraLock CurrentLock;

    /*
    [Header("Flight")]
    public float Force = 100;
    public float Mouse = 5;
    public float Roll = .5f;
    public float FlightZoomMax = 10;
    public float FlightZoomMin = 2;
    public float FlightZoomScale = 0.5f;
    public Vector3 CurrentVelocity;

    [Header("Tactical")]
    public float Speed = .25f;
    public float TacticalZoomMax = 10;
    public float TacticalZoomMin = 0;
    public float TacticalZoomScale = 0.5f;
    */

    [Header("Player Logic")]
    public bool bIsInPlay = true;
    public bool bIsInControl = true;
    public ControlMode CurrentMode = ControlMode.FLIGHT;

    void UpdateInput()
    {
        if (Input.GetButtonDown("ControlMode"))
        {
            if (CurrentMode == ControlMode.TACTICAL)
                CurrentMode = 0;
            else
                CurrentMode++;

            SnapCam();
        }

        if (!bIsInPlay)
            return;

        switch(CurrentMode)
        {
            case ControlMode.FLIGHT:
                FlightMode();
                break;

            case ControlMode.TACTICAL:
                TacticalMode();
                break;
        }
    }

    void SnapCam()
    {
        /*
        switch(CurrentMode)
        {
            case ControlMode.FLIGHT:
                if (Flight == null || Flight.GetChild(0) == null)
                    return;
                CameraMan.ReParent(Flight.GetChild(0));
                break;

            case ControlMode.TACTICAL:
                if (Tactical == null || Tactical.GetChild(0) == null)
                    return;
                CameraMan.ReParent(Tactical.GetChild(0));
                break;
        }
        */

        CurrentLock = CameraLockPoints.Find(x => x.Mode == CurrentMode);
        if (CurrentLock == null)
            return;

        CameraMan.ReParent(CurrentLock);

    }
    void FlightMode()
    {
        // Zoom
        //CameraMan.Zoom += CurrentLock.ZoomScale * -Input.mouseScrollDelta.y;
        //CameraMan.Zoom = (CameraMan.Zoom < CurrentLock.ZoomMin) ? CurrentLock.ZoomMin : CameraMan.Zoom;
        //CameraMan.Zoom = (CameraMan.Zoom > CurrentLock.ZoomMax) ? CurrentLock.ZoomMax : CameraMan.Zoom;

        if (bIsInControl)
        {
            // Looking
            if (Input.GetMouseButton(0))
            {
                float x = CurrentLock.MouseAxisScale * Input.GetAxisRaw("Mouse X");
                float y = CurrentLock.MouseAxisScale * Input.GetAxisRaw("Mouse Y");
                float z = 0;
                if (Input.GetButton("RollLeft"))
                    z += 1;
                if (Input.GetButton("RollRight"))
                    z -= 1;
                z *= CurrentLock.RollScale;

                CurrentLock.Pod.Rotate(-y, x, z, Space.Self);
            }

            // Movement
            if (Input.GetButton("Forward"))
                PhysicsObject.AddForce(CurrentLock.Pod.forward * CurrentLock.KeyAxisScale, ForceMode.Impulse);

            if (Input.GetButton("Backward"))
                PhysicsObject.AddForce(-CurrentLock.Pod.forward * CurrentLock.KeyAxisScale, ForceMode.Impulse);

            if (Input.GetButton("Right"))
                PhysicsObject.AddForce(CurrentLock.Pod.right * CurrentLock.KeyAxisScale, ForceMode.Impulse);

            if (Input.GetButton("Left"))
                PhysicsObject.AddForce(-CurrentLock.Pod.right * CurrentLock.KeyAxisScale, ForceMode.Impulse);

            if (Input.GetButton("Up"))
                PhysicsObject.AddForce(CurrentLock.Pod.transform.up * CurrentLock.KeyAxisScale, ForceMode.Impulse);

            if (Input.GetButton("Down"))
                PhysicsObject.AddForce(-CurrentLock.Pod.transform.up * CurrentLock.KeyAxisScale, ForceMode.Impulse);

            if (Input.GetButton("Break"))
            {
                PhysicsObject.velocity = new Vector3(0, 0, 0);
                PhysicsObject.angularVelocity = new Vector3(0, 0, 0);
            }
        }

        // Actions
        if (Input.GetButton("Focus") && Focus != null)
            CurrentLock.Pod.LookAt(Focus, Vector3.up);


    }
    void TacticalMode()
    {
        // Looking
        if (Input.GetMouseButton(0))
        {
            float x = CurrentLock.MouseAxisScale * Input.GetAxisRaw("Mouse X");
            float y = CurrentLock.MouseAxisScale * Input.GetAxisRaw("Mouse Y");

            CurrentLock.Pod.Rotate(-y, 0, 0, Space.Self);
            CurrentLock.Pod.Rotate(0, x, 0, Space.World);
        }

        // Zoom
        //CameraMan.Zoom += CurrentLock.ZoomScale * -Input.mouseScrollDelta.y;
        //CameraMan.Zoom = (CameraMan.Zoom < CurrentLock.ZoomMin) ? CurrentLock.ZoomMin : CameraMan.Zoom;
        //CameraMan.Zoom = (CameraMan.Zoom > CurrentLock.ZoomMax) ? CurrentLock.ZoomMax : CameraMan.Zoom;

        // Movement
        if (Input.GetButton("Forward"))
            CurrentLock.Pod.position += CurrentLock.Pod.forward * CurrentLock.KeyAxisScale;

        if (Input.GetButton("Backward"))
            CurrentLock.Pod.position -= CurrentLock.Pod.forward * CurrentLock.KeyAxisScale;

        if (Input.GetButton("Right"))
            CurrentLock.Pod.position += CurrentLock.Pod.right * CurrentLock.KeyAxisScale;

        if (Input.GetButton("Left"))
            CurrentLock.Pod.position -= CurrentLock.Pod.right * CurrentLock.KeyAxisScale;

        if (Input.GetButton("Up"))
            CurrentLock.Pod.position += CurrentLock.Pod.up * CurrentLock.KeyAxisScale;

        if (Input.GetButton("Down"))
            CurrentLock.Pod.position -= CurrentLock.Pod.up * CurrentLock.KeyAxisScale;

        // Selection
        if (Input.GetMouseButtonDown(0))
        {
            Ray ray;
            if (CameraMan.ReturnCameraRay(out ray))
            {
                RaycastHit hit;
                if (Physics.Raycast(ray, out hit))
                    FocusSelect(hit);
            }
        }
    }
    void FocusSelect(RaycastHit hit)
    {
        if (Gravity == null)
            return;

        PointMass selection = Gravity.PointMasses.Find(x => x.MassTransform == hit.transform);
        if (selection == null)
            return;
        Debug.Log(selection.Name);
        if (selection.CameraSnapPoint == null)
            return;
        CurrentLock.Socket.rotation = selection.CameraSnapPoint.rotation;
        CurrentLock.Socket.position = selection.CameraSnapPoint.position;
    }

    // Start is called before the first frame update
    void Start()
    {
        CurrentLock = CameraLockPoints[0];
        if (CurrentLock != null)
        {
            CameraMan.QuickSnap(CurrentLock.Socket);
            CameraMan.ReParent(CurrentLock);
        }
        else
            Debug.Log("failed to snap!");
    }

    // Update is called once per frame
    void Update()
    {
        UpdateInput();
    }
}
