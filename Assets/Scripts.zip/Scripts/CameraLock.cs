using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class CameraLock
{
    public ControlMode Mode;
    public Transform Socket;
    public Transform Boom;
    public Transform Pod;

    public Vector3 DefPos;
    public Vector3 DefRot;
    public Vector3 CurrentVelocity;

    public float ZoomMax;
    public float ZoomMin;
    public float ZoomScale;
    public float ZoomCurrent;

    public float KeyAxisScale;
    public float MouseAxisScale;
    public float RollScale;
}
