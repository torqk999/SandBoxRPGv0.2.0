using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
//using UnityEngine.UIElements;

public class UIManager : MonoBehaviour
{
    public CameraLock CurrentLock;
    public Canvas MyCanvas;
    public Slider MySliderPrefab;
    public Text MySliderTextPrefab;

    public int UICap = 7;

    public List<Slider> Sliders = new List<Slider>();
    public List<Text> SliderTexts = new List<Text>();

    void ValueChangeCheck()
    {
        for (int i = 0; i < UICap; i++)
            SliderTexts[i].text = Sliders[i].value.ToString();
    }

    void Start()
    {
        for (int i = 0; i < UICap; i++)
        {
            Slider newSlider = Instantiate(MySliderPrefab, MyCanvas.transform);
            Text newText = Instantiate(MySliderTextPrefab, MyCanvas.transform);
            newText.text = (0).ToString();
            newSlider.onValueChanged.AddListener(delegate { ValueChangeCheck(); });
            Sliders.Add(newSlider);
            SliderTexts.Add(newText);
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
