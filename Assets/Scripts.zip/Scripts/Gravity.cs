using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Gravity : MonoBehaviour
{

    public float gConst = 0.5f;
    public Rigidbody Player;
    public List<PointMass> PointMasses = new List<PointMass>();

    public void UpdateGravity()
    {
        AddForces();
    }

    void AddForces()
    {
        if (Player == null)
            return;

        foreach(PointMass mass in PointMasses)
        {
            double force = gConst * mass.Weight * (1 / (Math.Pow(Vector3.Distance(mass.MassTransform.position, Player.transform.position), 2)));
            Vector3 vector = mass.MassTransform.position - Player.transform.position;
            Player.AddForce(vector * (float)force, ForceMode.Acceleration);
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
